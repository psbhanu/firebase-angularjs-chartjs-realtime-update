# firebase-angularjs-chartjs-realtime-update

## Verify that you have PhP installed with your system:


##Start Server (build with PhP & Firebase SDK) (Run Following commands in your Command line / Terminal):
git clone https://github.com/psbhanu/firebase-angularjs-chartjs-realtime-update.git

cd firebase-angularjs-chartjs-realtime-update

php -S localhost:500

(Keep the Command line / Terminal open & Browse http://localhost:500/ in your web browser)


##Start Client (build with AngularJS, Char.js and Socket.io)  (Run Following commands in your Command line / Terminal):

cd client

php -S localhost:300

(Keep the Command line / Terminal open & Browse http://localhost:300/ in your web browser)

##Cheers!
